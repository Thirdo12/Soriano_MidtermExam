package com.example.soriano_midtermexam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.soriano_midtermexam.ui.theme.Soriano_MidtermExamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Soriano_MidtermExamTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OptionSelectionScreen()
                }
            }
        }
    }
}
// It is not finished yet because i am having difficulties sa device:( i want to add more screens and other questions, it is inspired by a tiktok filter which let you choose your most preferred agents in valorant by elimination each agent until the very last one
// Soriano, Aethird L.
@Composable
fun OptionSelectionScreen() {
    // Question, image, and options
    val questions = listOf(
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?",
        "Which Valorant Agent do you prefer?"
    )

    val images = listOf(
        R.drawable.astra to R.drawable.breach,
        R.drawable.brimstone to R.drawable.chamber,
        R.drawable.clove to R.drawable.cypher,
        R.drawable.deadlock to R.drawable.fade,
        R.drawable.gekko to R.drawable.harbor,
        R.drawable.iso to R.drawable.kayo,
        R.drawable.killjoy to R.drawable.neon,
        R.drawable.omen to R.drawable.phoenix,
        R.drawable.raze to R.drawable.reyna,
        R.drawable.sage to R.drawable.skye,
        R.drawable.sova to R.drawable.jett,
        R.drawable.viper to R.drawable.yoru
    )

    val options = listOf(
        listOf("Astra", "Breach"),
        listOf("Brimstone", "Chamber"),
        listOf("Clove", "Cypher"),
        listOf("Deadlock", "Fade"),
        listOf("Gekko", "Harbor"),
        listOf("Iso", "K/ayo"),
        listOf("Killjoy", "Neon"),
        listOf("Omen", "Phoenix"),
        listOf("Raze", "Reyna"),
        listOf("Sage", "Skye"),
        listOf("Sova", "Jett"),
        listOf("Viper", "Yoru")
    )

    // nag ttrack through stacking values ganon lang din yung sa options ginawa ko syang "" instead of null kasi mag kakaroon pa sya ng value pag nag patuloy yung app
    val currentQuestionIndex = remember { mutableStateOf(0) }
    val selectedOption = remember { mutableStateOf("") }
    val selectedOptions = remember { mutableStateOf(mutableListOf<String>()) }

    // sinet yung value nila sa false then once na mag true maaactivate yung mga functions nila
    val reminderShown = remember { mutableStateOf(false) }
    val displayAnswersScreen = remember { mutableStateOf(false) }

    if (displayAnswersScreen.value) {
        // final screen
        DisplayAnswersScreen(selectedOptions.value)
        return
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Display current question
        Text(
            text = questions[currentQuestionIndex.value],
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Display images for current question
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = images[currentQuestionIndex.value].first),
                contentDescription = null,
                modifier = Modifier.size(150.dp)
            )
            Image(
                painter = painterResource(id = images[currentQuestionIndex.value].second),
                contentDescription = null,
                modifier = Modifier.size(150.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Option buttons
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            options[currentQuestionIndex.value].forEach { option ->
                OptionButton(option) {
                    selectedOption.value = option
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Back button
        if (currentQuestionIndex.value > 0) {
            Button(
                onClick = {
                    // nag babawas ng value para manavigate back
                    currentQuestionIndex.value--
                    // then marereset yung value ng selectedoption when the condition is met
                    selectedOption.value = ""
                }
            ) {
                Text(text = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
        }

        // Next button
        Button(
            onClick = {
                if (selectedOption.value.isEmpty()) {
                    reminderShown.value = true
                } else {
                    // eto naman nag aadd ng value
                    currentQuestionIndex.value++
                    // nag aadd ng value sa selectedoption
                    selectedOptions.value.add(selectedOption.value)
                    selectedOption.value = ""
                    // if last question magiging true yung displayanswerscreen which means mapupunta tayo doon kasi magiging true nga yung value kasi gumamit ako ng if statement
                    if (currentQuestionIndex.value == questions.size) {
                        displayAnswersScreen.value = true
                    }
                }
            },
            // Enable button until last
            enabled = currentQuestionIndex.value < questions.size
        ) {
            Text(text = if (currentQuestionIndex.value == questions.size - 1) "Finish" else "Next")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Selected Option: ${selectedOption.value}")

        // i used Snackbar for reminders
        if (reminderShown.value) {
            Snackbar(
                modifier = Modifier.padding(16.dp),
                action = {
                    Button(onClick = { reminderShown.value = false }) {
                        Text("Dismiss")
                    }
                }
            ) {
                Text("Please select an option before proceeding.")
            }
        }
    }
}

@Composable
fun OptionButton(option: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.padding(8.dp)
    ) {
        Text(text = option)
    }
}

@Composable
fun DisplayAnswersScreen(answers: List<String>) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("These are the Agents you prefer:", modifier = Modifier.padding(bottom = 16.dp))
        answers.forEach {
            Text(it)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun OptionSelectionScreenPreview() {
    Soriano_MidtermExamTheme {
        OptionSelectionScreen()
    }
}